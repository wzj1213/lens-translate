"use strict";(()=>{function a(n,e){try{return chrome.i18n.getMessage(n,e)||n}catch{return n}}function b(n,e){n.addEventListener("click",t=>{t.isTrusted&&(t.preventDefault(),t.stopPropagation(),e())})}function he(){try{return window.top===window}catch{return!1}}function Ge(){try{return typeof chrome<"u"&&!!chrome.runtime?.id}catch{return!1}}function x(){if(!Ge())throw new Error("Extension context invalidated.")}function g(n){let e=n instanceof Error?n.message:String(n??"");return e.includes("Extension context invalidated")?a("toastContextInvalid"):e||a("toastFailed")}function p(n){return String(n??"").replace(/\s+/g," ").trim()}function m(n,e,t,r){let o=Number.parseInt(String(n),10);return Number.isFinite(o)?Math.min(t,Math.max(e,o)):r}function me(n,e,t,r){let o=Number.parseFloat(String(n));return Number.isFinite(o)?Math.min(t,Math.max(e,o)):r}function fe(n){return/[\p{L}]/u.test(n)}function be(n){return/^https?:\/\/\S+$/i.test(n)||/^[\w.+-]+@[\w.-]+\.\w+$/.test(n)?!0:n.replace(/[^\p{L}\p{N}]/gu,"").length/Math.max(n.length,1)<.15}function ge(n){let e=p(n);if(!e||e.length>40||/[.!?。！？,，;；:：]\s/.test(e)||!/[\p{L}]/u.test(e))return!1;let t=e.split(" ");return t.length>5?!1:t.length===1?!!(/\d/.test(e)||/[a-z][A-Z]/.test(e)||/[_/\\]/.test(e)):/\d/.test(e)?t.every(r=>{if(/^\(.*\)$/.test(r))return!0;let o=r.replace(/[()[\]{}.,]/g,"");return!o||!/[a-zA-Z]/.test(o)||/\d/.test(o)||/[-_/]/.test(o)||/[a-z][A-Z]/.test(o)?!0:/^[A-Z]/.test(o)}):!1}function ve(n){let e=globalThis.crypto;return e?.randomUUID?`${n}_${e.randomUUID()}`:`${n}_${Date.now().toString(36)}_${Math.floor(Math.random()*1e9).toString(36)}`}function L(n){let e=n;return e?!!(e.nodeType===Node.ELEMENT_NODE?e:e.parentElement)?.closest?.("[data-lens-ui]"):!1}function Z(){if(document.designMode?.toLowerCase()==="on")return!0;let n=window.getSelection();return[n?.anchorNode,n?.focusNode].some(e=>{let t=e?.nodeType===Node.ELEMENT_NODE?e:e?.parentElement;if(t?.closest("input, textarea"))return!0;let r=t?.closest("[contenteditable]")?.getAttribute("contenteditable")?.toLowerCase();return r===""||r==="true"||r==="plaintext-only"})}function I(){let n=window.getSelection();if(!n||n.rangeCount===0||n.isCollapsed)return null;let e=p(n.toString());if(e.length<1||e.length>8e3||L(n.anchorNode)||L(n.focusNode))return null;let t=n.getRangeAt(0),r=[...t.getClientRects()].filter(i=>i.width>0&&i.height>0),o=r[r.length-1]??t.getBoundingClientRect();return!o||o.width===0||o.height===0?null:{text:e,rect:o}}function xe(n,e,t){return Math.min(t,Math.max(e,n))}function F(n,e,t){let r=t.gap,o=n.offsetWidth||320,i=n.offsetHeight||120,s=10,l=xe(e.left+e.width/2-o/2,s,Math.max(s,window.innerWidth-o-s)),h=e.bottom+r,d=e.top-i-r,S=h+i<=window.innerHeight-s,M=d>=s,v=t.preferred==="above"&&M?d:h;!S&&M&&(v=d),v=xe(v,s,Math.max(s,window.innerHeight-i-s)),n.style.left=`${l}px`,n.style.top=`${v}px`}var B=class{constructor(e){this.translate=e}translate;el=null;info=null;timer=null;mode="off";onMouseUp=e=>{L(e.target)||this.schedule(80)};onKeyUp=e=>{let t=e.key;if(t==="Escape")return this.hide();(t.startsWith("Arrow")||t==="Home"||t==="End")&&this.schedule(80)};onMouseDown=e=>{L(e.target)||this.hide()};onViewportChange=()=>this.hide();setMode(e){this.mode!==e&&(this.mode=e,this.hide())}openManually(){return this.mode==="off"?!1:(this.hide(),this.show(!0))}init(){document.addEventListener("mouseup",this.onMouseUp,!0),document.addEventListener("keyup",this.onKeyUp,!0),document.addEventListener("mousedown",this.onMouseDown,!0),window.addEventListener("scroll",this.onViewportChange,!0),window.addEventListener("resize",this.onViewportChange)}destroy(){this.hide(),document.removeEventListener("mouseup",this.onMouseUp,!0),document.removeEventListener("keyup",this.onKeyUp,!0),document.removeEventListener("mousedown",this.onMouseDown,!0),window.removeEventListener("scroll",this.onViewportChange,!0),window.removeEventListener("resize",this.onViewportChange),this.el?.remove(),this.el=null}hide(){this.timer&&(clearTimeout(this.timer),this.timer=null),this.el&&(this.el.dataset.visible="false"),this.info=null}schedule(e){if(this.mode!=="auto"||Z())return this.hide();this.timer&&clearTimeout(this.timer),this.timer=setTimeout(()=>{this.timer=null,this.mode==="auto"&&!Z()&&this.show()},e)}show(e=!1){let t=I();if(!t)return this.hide(),!1;this.info=t;let r=this.ensure();return r.dataset.visible="true",F(r,t.rect,{gap:8,preferred:e?"below":"above"}),!0}ensure(){if(this.el)return this.el;let e=document.createElement("div");e.className="lens-selbar",e.dataset.lensUi="selection-bar",e.dataset.visible="false",e.addEventListener("mousedown",r=>r.preventDefault());let t=document.createElement("button");return t.type="button",t.className="lens-selbar-btn",t.textContent=a("translateSelection"),b(t,()=>{let r=this.info;this.hide(),r&&this.translate(r)}),e.appendChild(t),document.documentElement.appendChild(e),this.el=e,e}},ye=`
.lens-selbar {
  position: fixed;
  z-index: 2147483600;
  display: none;
  align-items: center;
  gap: 2px;
  padding: 4px;
  background: var(--lens-srf);
  border: 1px solid var(--lens-line);
  border-radius: var(--lens-r-sm);
  box-shadow: var(--lens-shadow);
  font-family: var(--lens-font);
  font-size: 13px;
  line-height: 1;
  color: var(--lens-fg);
  white-space: nowrap;
  user-select: none;
}
.lens-selbar[data-visible="true"] { display: flex; }
.lens-selbar-btn {
  appearance: none;
  border: 0;
  background: none;
  color: var(--lens-fg-2);
  font: inherit;
  padding: 5px 9px;
  border-radius: 5px;
  cursor: pointer;
}
.lens-selbar-btn:hover { background: var(--lens-srf-2); color: var(--lens-fg); }
`;function J(n){let e=Ke(n??"",{allowPrivate:!0});return e.ok?e.url.origin:""}function Ke(n,e={}){let t;try{t=new URL(n)}catch{return{ok:!1,reason:"Endpoint is not a valid URL."}}return t.protocol!=="http:"&&t.protocol!=="https:"?{ok:!1,reason:"Endpoint must use http or https."}:t.username||t.password?{ok:!1,reason:"Put credentials in the API Key field."}:!e.allowPrivate&&Ee(t.hostname)?{ok:!1,reason:"Endpoint points to a private or loopback address."}:{ok:!0,url:t}}function Ee(n){let e=n.toLowerCase().replace(/^\[|\]$/g,"");if(e==="localhost"||e.endsWith(".local")||e.endsWith(".localhost")||e==="::1"||e==="0.0.0.0"||e==="::"||e==="0:0:0:0:0:0:0:0")return!0;let t=e.match(/^::ffff:(.+)$/);if(t){let o=t[1],i=o.match(/^([0-9a-f]{1,4}):([0-9a-f]{1,4})$/);if(i){let s=parseInt(i[1],16),l=parseInt(i[2],16);o=`${s>>8&255}.${s&255}.${l>>8&255}.${l&255}`}return Ee(o)}let r=e.match(/^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/);if(r){let o=Number(r[1]),i=Number(r[2]);if(o===127||o===10||o===0||o===169&&i===254||o===172&&i>=16&&i<=31||o===192&&i===168)return!0}return!!(/^f[cd][0-9a-f]{2}:/.test(e)||e.startsWith("fe80:"))}var Ye=["auto","manual","off"];function Te(n){if(!Array.isArray(n))return[];let e=[],t=new Set;for(let r of n){if(!r||typeof r.origin!="string"||!Ye.includes(r.mode))continue;let o=J(r.origin);!o||t.has(o)||(t.add(o),e.push({origin:o,mode:r.mode}))}return e}function Q(n,e){let t=J(e);return n.selectionToolbarRules.find(r=>r.origin===t)?.mode??"auto"}var E="lensSettings";var _="aiTranslatorSettings";var c={provider:"custom",protocol:"openai",endpoint:"",apiKey:"",model:"gpt-4o-mini",targetLang:"\u7B80\u4F53\u4E2D\u6587",sourceSkip:!0,translateUiText:!0,glossary:"",displayMode:"bilingual",translationColor:"green",theme:"system",temperature:.2,maxSegments:320,maxConcurrency:10,batchMaxItems:8,batchMaxChars:2400,requestTimeoutMs:45e3,cacheEnabled:!0,cacheTtlDays:30,cacheMaxEntries:8e3,floatingBubbleEnabled:!0,autoTranslateEnabled:!1,autoTranslateBatchSize:80,autoTranslatePrefetchScreens:1,autoTranslateDebounceMs:400,siteRules:[],selectionToolbarRules:[]};var we=["green","black","blue","purple","amber"],ee={black:{text:"#18181B",background:"rgba(24, 24, 27, 0.05)",border:"#52525B"},green:{text:"#0F766E",background:"rgba(15, 118, 110, 0.08)",border:"#14B8A6"},blue:{text:"#1D4ED8",background:"rgba(29, 78, 216, 0.07)",border:"#3B82F6"},purple:{text:"#6D28D9",background:"rgba(109, 40, 217, 0.07)",border:"#8B5CF6"},amber:{text:"#B45309",background:"rgba(180, 83, 9, 0.09)",border:"#D97706"}};var Se=[.5,1,1.5,2],qe={\u7B80\u4F53\u4E2D\u6587:"zh-Hans",\u7E41\u9AD4\u4E2D\u6587:"zh-Hant",English:"en",\u65E5\u672C\u8A9E:"ja",\uD55C\uAD6D\uC5B4:"ko",Fran\u00E7ais:"fr",Deutsch:"de",Espa\u00F1ol:"es",\u0420\u0443\u0441\u0441\u043A\u0438\u0439:"ru",Portugu\u00EAs:"pt",Italiano:"it",\u0627\u0644\u0639\u0631\u0628\u064A\u0629:"ar"};function U(n){return qe[n?.trim()]??null}var je=new Set(["zh","ja","ko","ru","ar","he","el","th","hi"]);function Xe(n){let e=n.slice(0,600),t={},r=0;for(let l of e){let h=l.codePointAt(0)??0,d=Ze(h);d&&(t[d]=(t[d]??0)+1,r+=1)}if(r===0)return"unknown";if((t.kana??0)>0)return"ja";if((t.hangul??0)>0)return"ko";if((t.han??0)>0)return"zh";let o=["cyrillic","arabic","hebrew","greek","thai","devanagari","latin"].map(l=>[l,t[l]??0]).sort((l,h)=>h[1]-l[1]),[i,s]=o[0];if(s===0)return"unknown";switch(i){case"cyrillic":return"ru";case"arabic":return"ar";case"hebrew":return"he";case"greek":return"el";case"thai":return"th";case"devanagari":return"hi";default:return"latin"}}function Ze(n){return n>=12352&&n<=12543||n>=12784&&n<=12799?"kana":n>=44032&&n<=55203?"hangul":n>=19968&&n<=40959||n>=13312&&n<=19903||n>=63744&&n<=64255?"han":n>=1024&&n<=1279?"cyrillic":n>=1536&&n<=1791||n>=1872&&n<=1919?"arabic":n>=1424&&n<=1535?"hebrew":n>=880&&n<=1023?"greek":n>=3584&&n<=3711?"thai":n>=2304&&n<=2431?"devanagari":n>=65&&n<=90||n>=97&&n<=122||n>=192&&n<=591?"latin":null}var Je=[[/中文|汉语|漢語|chinese|zh|cn/i,"zh"],[/日本語|日语|japanese|ja|jp/i,"ja"],[/한국|韩语|korean|ko|kr/i,"ko"],[/english|英语|英文|^en$/i,"en"],[/русск|russian|^ru$/i,"ru"],[/عربية|arabic|^ar$/i,"ar"],[/עברית|hebrew|^he$/i,"he"],[/ελλην|greek|^el$/i,"el"],[/ไทย|thai|^th$/i,"th"]];function Qe(n){let e=String(n||"").trim();for(let[t,r]of Je)if(t.test(e))return r;return"unknown"}var et=new Set(["the","and","of","to","in","is","it","you","that","for","on","with","as","are","this","be","at","by","an","or","we","your","can","will","from","have","not"]);function tt(n){let e=n.replace(/[^\x00-\x7f]/g,"");if(e.length/Math.max(n.length,1)<.85)return!1;let t=e.toLowerCase().match(/[a-z']+/g)??[];if(t.length<3)return!1;let r=0,o=new Set;for(let i of t)et.has(i)&&!o.has(i)&&(o.add(i),r+=1);return r>=2}function Me(n,e){let t=Qe(e);if(t==="unknown")return!1;let r=Xe(n);return je.has(t)?r===t:t==="en"?r==="latin"&&tt(n):!1}var nt=["openai","anthropic","moonshot","deepseek","zhipu","siliconflow","gemini","custom"],rt=["openai","anthropic"],ot=["system","light","dark"],it=["bilingual","replace"],st=["always","never","auto"];function P(n,e,t){return n.includes(e)?e:t}function T(n){let e={...c,...n??{}},t=Number(e.autoTranslatePrefetchScreens);return{provider:P(nt,e.provider,"custom"),protocol:P(rt,e.protocol,"openai"),endpoint:String(e.endpoint??"").trim(),apiKey:String(e.apiKey??"").trim(),model:String(e.model??"").trim()||c.model,targetLang:String(e.targetLang??"").trim()||c.targetLang,sourceSkip:e.sourceSkip!==!1,translateUiText:e.translateUiText!==!1,glossary:String(e.glossary??""),displayMode:P(it,e.displayMode,"bilingual"),translationColor:P(we,e.translationColor,c.translationColor),theme:P(ot,e.theme,"system"),temperature:me(e.temperature,0,2,c.temperature),maxSegments:m(e.maxSegments,50,1200,c.maxSegments),maxConcurrency:m(e.maxConcurrency,1,24,c.maxConcurrency),batchMaxItems:m(e.batchMaxItems,4,100,c.batchMaxItems),batchMaxChars:m(e.batchMaxChars,1e3,16e3,c.batchMaxChars),requestTimeoutMs:m(e.requestTimeoutMs,8e3,12e4,c.requestTimeoutMs),cacheEnabled:e.cacheEnabled!==!1,cacheTtlDays:m(e.cacheTtlDays,1,365,c.cacheTtlDays),cacheMaxEntries:m(e.cacheMaxEntries,500,5e4,c.cacheMaxEntries),floatingBubbleEnabled:e.floatingBubbleEnabled!==!1,autoTranslateEnabled:e.autoTranslateEnabled===!0,autoTranslateBatchSize:m(e.autoTranslateBatchSize,10,200,c.autoTranslateBatchSize),autoTranslatePrefetchScreens:Se.includes(t)?t:c.autoTranslatePrefetchScreens,autoTranslateDebounceMs:m(e.autoTranslateDebounceMs,200,3e3,c.autoTranslateDebounceMs),siteRules:at(e.siteRules),selectionToolbarRules:Te(e.selectionToolbarRules)}}function at(n){if(!Array.isArray(n))return[];let e=[],t=new Set;for(let r of n){let o=String(r?.host??"").trim().toLowerCase(),i=r?.mode;!o||t.has(o)||!st.includes(i)||(t.add(o),e.push({host:o,mode:i}))}return e}async function A(){let n=await chrome.storage.local.get([E,_]),e=n[E];if(e)return T(e);let t=n[_];if(t){let r=T(t);return await chrome.storage.local.set({[E]:r}),await chrome.storage.local.remove(_),r}return T(void 0)}async function H(n){await chrome.storage.local.set({[E]:n})}function w(n){let e=String(n||"").trim().toLowerCase();return e=e.replace(/^[a-z]+:\/\//,"").replace(/\/.*$/,"").replace(/:\d+$/,""),e}function Ae(n,e){let t=w(e);if(!t)return null;let r=null;for(let o of n){let i=w(o.host);if(!i)continue;let s=lt(i,t);s!==0&&(!r||s>r.score||s===r.score&&i.length>r.len)&&(r={mode:o.mode,score:s,len:i.length})}return r?.mode??null}function lt(n,e){if(n===e)return 3;if(n.startsWith("*.")){let t=n.slice(2);return e===t||e.endsWith(`.${t}`)?2:0}return e===n||e.endsWith(`.${n}`)?1:0}function ut(n,e,t){let r=w(e);if(!r)return n;let o=n.filter(i=>w(i.host)!==r);return o.push({host:r,mode:t}),o.sort((i,s)=>i.host.localeCompare(s.host)),o}function ct(n,e){let t=w(e);return n.filter(r=>w(r.host)!==t)}function te(n,e){let t=Ae(n.siteRules,e);return t==="always"?!0:t==="never"?!1:n.autoTranslateEnabled}function Re(n,e,t){let r=w(e);if(!r)return n.siteRules;let o=ct(n.siteRules,r),i=Ae(o,r);return(i==="always"?!0:i==="never"?!1:n.autoTranslateEnabled)===t?o:ut(o,r,t?"always":"never")}var dt=new Set(["SCRIPT","STYLE","NOSCRIPT","TEXTAREA","INPUT","SELECT","OPTION","CODE","PRE","KBD","SAMP","SVG","CANVAS","MATH","IFRAME","OBJECT","EMBED","VIDEO","AUDIO"]),pt=new Set(["P","DIV","LI","UL","OL","H1","H2","H3","H4","H5","H6","BLOCKQUOTE","TD","TH","DD","DT","DL","FIGCAPTION","FIGURE","SECTION","ARTICLE","ASIDE","HEADER","FOOTER","MAIN","NAV","FORM","TABLE","TR","CAPTION","ADDRESS","DETAILS","SUMMARY","BODY"]),ht=new Set(["block","list-item","table-cell","table-caption","flex","grid","flow-root","table","table-row"]),mt="table,thead,tbody,tfoot,tr,colgroup,select,optgroup,datalist,[role='table'],[role='grid'],[role='row'],[role='rowgroup'],[role='tablist'],[role='listbox']",ft="td,th,caption,button,summary,label,[role='gridcell'],[role='cell'],[role='columnheader'],[role='rowheader'],[role='tab'],[role='button'],[role='option'],[role='menuitem']",bt="nav,[role='navigation'],[role='menu'],[role='menubar'],[role='toolbar']",gt=24,vt=40,xt=2,yt=2e3,Et="nav,aside,[role='navigation'],[role='banner'],[role='contentinfo'],[role='complementary'],[role='menu'],[role='menubar'],[role='toolbar'],[role='tablist'],[role='search']",Tt="article,section,main,[role='article'],[role='main']",Ce="a,button,summary,label,[role='button'],[role='link'],[role='tab'],[role='menuitem'],[role='option']",wt=30,St=3,Mt=.8,Le=!0;function oe(n){Le=n}var ne=new WeakMap,z=new WeakMap;function Pe(){ne=new WeakMap,z=new WeakMap}function Ne(n){let e=p(n);return!(e.length<xt||e.length>yt||!fe(e)||be(e))}function Oe(n){let e=ne.get(n);if(e!==void 0)return e;let t=null;try{t=n.ownerDocument.defaultView?.getComputedStyle(n)??null}catch{t=null}return ne.set(n,t),t}function At(n){for(let e=n;e;e=e.parentElement){if(dt.has(e.tagName)||e.getAttribute("aria-hidden")==="true"||e instanceof HTMLElement&&(e.isContentEditable||e.dataset.lens||e.dataset.lensUi))return!0;if(e.tagName==="BODY"||e.tagName==="HTML")break}return!1}function Rt(n){if(n.closest(Et))return!0;let e=n.closest("header,footer");return!!(e&&!e.parentElement?.closest(Tt))}function Ct(n,e){let t=n.closest(Ce)??n.querySelector(Ce);return!t||p(t.textContent??"")!==e?!1:e.length<=wt?!0:kt(t)}function kt(n){let e=n.parentElement;for(let t=0;e&&t<3;t+=1,e=e.parentElement){let r=[...e.querySelectorAll("a[href]")];if(r.length<St)continue;let o=r.reduce((s,l)=>s+p(l.textContent??"").length,0),i=p(e.textContent??"").length;if(i>0&&o/i>=Mt)return!0}return!1}function Lt(n){let e=n.ownerDocument.documentElement,t=[],r=n,o=!0;for(;r&&r!==e;){let i=z.get(r);if(i!==void 0){o=i;break}let s=Oe(r);if(s){if(s.display==="none"||s.visibility==="hidden"||s.visibility==="collapse"){o=!1;break}if(s.opacity!==""&&Number(s.opacity)===0){o=!1;break}}t.push(r),r=r.parentElement}r&&r!==e&&o===!1&&z.set(r,!1);for(let i of t)z.set(i,o);return o}function Pt(n){let e=n.parentElement;for(;e;){if(pt.has(e.tagName))return e;let t=Oe(e);if(t&&ht.has(t.display)||e.tagName==="BODY")return e;e=e.parentElement}return null}function ke(n,e){try{return n.matches(e)}catch{return!1}}function Nt(n,e,t){return ke(n,mt)?"attribute":t?"swap":ke(n,ft)?e.length<=gt?"inline":"block":e.length<=vt&&n.closest(bt)?"inline":"block"}function re(n,e=Ne){let t=new Map,o=(n.ownerDocument??document).createTreeWalker(n,NodeFilter.SHOW_TEXT,{acceptNode(i){let s=i;if(!e(s.nodeValue??""))return NodeFilter.FILTER_REJECT;let l=s.parentElement;return!l||At(l)||!Lt(l)?NodeFilter.FILTER_REJECT:NodeFilter.FILTER_ACCEPT}});for(;o.nextNode();){let i=o.currentNode,s=Pt(i);if(!s)continue;let l=t.get(s);l?l.push(i):t.set(s,[i])}return t}function De(n,e){let t=p(e.map(o=>o.nodeValue??"").join(" "));if(!Ne(t)||ge(t))return null;let r=Rt(n)||Ct(n,t);return r&&!Le?null:{block:n,nodes:e,text:t,renderMode:Nt(n,t,r)}}function ie(n){let e=[],r=(n.ownerDocument??document).createTreeWalker(n,NodeFilter.SHOW_ELEMENT,{acceptNode:o=>o.shadowRoot?NodeFilter.FILTER_ACCEPT:NodeFilter.FILTER_SKIP});for(;r.nextNode();){let o=r.currentNode.shadowRoot;o&&(e.push(o),e.push(...ie(o)))}return e}function $(n=document.body){if(!n)return[];Pe();let e=[n,...ie(n)],t=[];for(let r of e)for(let[o,i]of re(r)){let s=De(o,i);s&&t.push(s)}return t}function se(n){Pe();let e=[],t=new Set;for(let r of n)if(r.isConnected)for(let o of[r,...ie(r)])for(let[i,s]of re(o)){if(t.has(i))continue;t.add(i);let h=o.contains?.(i)??!1?s:re(i).get(i)??s,d=De(i,h);d&&e.push(d)}return e}function Ot(n){for(let e of n.nodes){let t=document.createRange();try{t.selectNodeContents(e);for(let r of t.getClientRects())if(r.width>0&&r.height>0)return r}catch{}finally{t.detach()}}try{return n.block.getBoundingClientRect()}catch{return null}}function Ie(n){return n?(n.bottom>=0&&n.top<=window.innerHeight?0:1e5)+Math.abs(n.top):Number.MAX_SAFE_INTEGER}function Dt(n,e,t){return!n||n.width<=0||n.height<=0?!1:n.bottom>=-e&&n.top<=window.innerHeight+t&&n.right>=-160&&n.left<=window.innerWidth+160}function N(n){let e=n.marginTop??160,t=n.marginBottom??160,r=$(document.body).map(i=>{let s=Ot(i);return{unit:i,rect:s,visible:n.viewportOnly?Dt(s,e,t):!0}}),o=r;if(n.viewportOnly){let i=r.filter(s=>s.visible);i.length&&(o=i)}return o.sort((i,s)=>Ie(i.rect)-Ie(s.rect)),o.slice(0,n.limit).map(i=>i.unit)}var Fe="lens-style",Be=new Set;function It(){let n=document.getElementById(Fe);if(n)return n;let e=document.createElement("style");return e.id=Fe,e.dataset.lensUi="style",(document.head??document.documentElement).appendChild(e),e}function y(){ae("base",Ft)}function ae(n,e){if(Be.has(n))return;Be.add(n);let t=It();t.textContent=`${t.textContent??""}
${e}`}function le(n){let e=ee[n]??ee.green,t=document.documentElement.style;t.setProperty("--lens-color",e.text),t.setProperty("--lens-bg",e.background),t.setProperty("--lens-border",e.border)}var Ft=`
/* ============================================================================
   AI Bilingual Translator \u2014 content (injected into arbitrary pages)
   Ink + single accent (teal). Near-monochrome ink, ONE focal accent per surface;
   everywhere else ink text + 1px hairlines. Namespaced --lens- tokens.
   ============================================================================ */

:root {
  /* Surface + ink */
  --lens-srf: #FFFFFF;
  --lens-srf-2: #FAFAF9;
  --lens-fg: #18181B;
  --lens-fg-2: #3F3F46;
  --lens-muted: #6B6B73;
  --lens-line: #E4E4E7;
  --lens-line-2: #D4D4D8;

  /* The single accent \u2014 focal only */
  --lens-accent: #0F766E;
  --lens-accent-hover: #0B5E57;
  --lens-on-accent: #FFFFFF;

  /* Tone (feedback only) */
  --lens-warning: #B45309;
  --lens-error: #B42318;

  /* One restrained elevation token \u2014 no colored / glow shadows */
  --lens-shadow: 0 1px 2px rgba(24,24,27,0.06), 0 8px 24px rgba(24,24,27,0.10);

  /* Radii: 8px chrome/chips/inputs, 12px popovers/anchors. Never 50% / 999px. */
  --lens-r-sm: 8px;
  --lens-r-lg: 12px;

  /* Floating button edge length (draggable; smaller, restrained anchor). */
  --lens-fab: 38px;

  --lens-font: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
  --lens-ease: cubic-bezier(0.2, 0, 0, 1);
}

@media (prefers-color-scheme: dark) {
  :root {
    --lens-srf: #1C1C1F;
    --lens-srf-2: #141416;
    --lens-fg: #FAFAF9;
    --lens-fg-2: #D4D4D8;
    --lens-muted: #A1A1AA;
    --lens-line: rgba(255,255,255,0.10);
    --lens-line-2: rgba(255,255,255,0.16);
    --lens-accent: #2DD4BF;          /* bright teal = text/active accent only */
    --lens-accent-hover: #5EEAD4;
    --lens-warning: #FBBF24;
    --lens-error: #FB7185;
    --lens-shadow: 0 1px 2px rgba(0,0,0,0.40), 0 8px 24px rgba(0,0,0,0.45);
  }
}

/* ============================================================================
   Injected translation text.
   Hardening first: these nodes live inside arbitrary page CSS, so every property
   a host page commonly sets on its text containers (uppercase transforms, wide
   letter-spacing, nowrap, text-indent, line-clamp, transparent text-fill for
   gradient headings, floats) is neutralized here. Without this the translation
   inherits styling meant for a headline and renders unreadable or invisible.
   ============================================================================ */
[data-lens-ui="tr"] {
  float: none !important;
  clear: none !important;
  position: static !important;
  visibility: visible !important;
  opacity: 1 !important;
  text-transform: none !important;
  letter-spacing: normal !important;
  word-spacing: normal !important;
  white-space: normal !important;
  text-indent: 0 !important;
  text-align: start;
  text-shadow: none !important;
  text-decoration: none !important;
  font-style: normal;
  font-variant: normal;
  -webkit-text-stroke: 0 !important;
  -webkit-text-fill-color: currentColor !important;
  -webkit-line-clamp: none !important;
  max-height: none !important;
  overflow: visible !important;
  overflow-wrap: break-word;
  word-break: normal;
  user-select: text;
  vertical-align: baseline;
  box-decoration-break: clone;
  -webkit-box-decoration-break: clone;
  direction: inherit;
  unicode-bidi: isolate;
}

/* Match the surrounding paragraph typography and use the selected translation colour. */
.lens-block, .lens-inline {
  color: var(--lens-color, #0F766E) !important;
  background: none !important;
  border: 0;
  padding: 0;
  font: inherit;
  font-size: inherit;
  font-weight: inherit;
  line-height: inherit;
}
.lens-block {
  display: block;
  max-width: 100%;
  margin: 0.28em 0 0.15em;
  /* Own a full line in flex/grid parents instead of becoming a sibling column.
     Ignored outside flex/grid, so it is safe to set unconditionally. Shrink is
     left enabled (with min-width:0) so a nowrap flex row can never be forced to
     overflow by the injected line. */
  flex: 1 1 100%;
  min-width: 0;
  grid-column: 1 / -1;
}
.lens-inline {
  display: inline;
  margin-inline-start: 0.4em;
}
/* Translation-only mode: the translation IS the paragraph, so it must inherit
   the page's own text styling rather than announce itself. */
.lens-replace {
  display: inline;
  color: inherit;
  background: transparent;
  font: inherit;
  line-height: inherit;
}

/* Pending: a one-line shimmer sized like the incoming text, so the real
   translation replaces it without a second layout shift. No placeholder copy. */
.lens-pending { color: transparent !important; background: transparent !important; }
.lens-pending::after {
  content: "";
  display: inline-block;
  width: 5.5em; max-width: 60%; height: 0.72em;
  vertical-align: middle; border-radius: 4px;
  background: linear-gradient(90deg, var(--lens-line) 25%, var(--lens-line-2) 37%, var(--lens-line) 63%);
  background-size: 300% 100%;
  animation: lens-shimmer 1.3s ease-in-out infinite;
}
.lens-error {
  color: var(--lens-error) !important;
  background: transparent !important;
  font-size: clamp(11px, 0.82em, 14px);
  opacity: 0.8;
  cursor: help;
}
[data-lens="attr"] {
  text-decoration: underline dotted var(--lens-border, #14b8a6);
  text-underline-offset: 0.18em;
  cursor: help;
}

@keyframes lens-shimmer {
  0%   { background-position: 100% 0; }
  100% { background-position: 0 0; }
}

/* ============================================================================
   Selection toolbar \u2014 one flat hairline button. Click TRANSLATES (no caret).
   Ink chrome; the only color is the small accent "\u8BD1" tile.
   ============================================================================ */
.lens-selection-bubble {
  position: fixed; z-index: 2147483647;
  display: inline-flex; align-items: center; gap: 8px;
  min-height: 34px; padding: 0 12px 0 8px;
  border: 1px solid var(--lens-line);
  border-radius: var(--lens-r-sm);
  color: var(--lens-fg-2); background: var(--lens-srf);
  box-shadow: var(--lens-shadow);
  cursor: pointer;
  font: 500 13px/1 var(--lens-font);
  letter-spacing: -0.005em;
  opacity: 0; pointer-events: none; transform: translateY(1px);
  transition: opacity .14s var(--lens-ease), transform .14s var(--lens-ease),
              border-color .14s var(--lens-ease), background-color .14s var(--lens-ease),
              color .14s var(--lens-ease);
}
.lens-selection-bubble[data-visible="true"] { opacity: 1; pointer-events: auto; transform: none; }
.lens-selection-bubble:hover { background: var(--lens-srf-2); border-color: var(--lens-line-2); color: var(--lens-fg); }
.lens-selection-bubble:active { transform: translateY(1px); }
.lens-selection-bubble:focus-visible { outline: 2px solid var(--lens-accent); outline-offset: 2px; }
.lens-selection-bubble-mark {
  display: inline-grid; place-items: center; width: 20px; height: 20px;
  border-radius: 6px; color: var(--lens-on-accent); background: var(--lens-accent);
  font-size: 12px; font-weight: 600;
}

/* ============================================================================
   Selection panel \u2014 chrome is ink; the translated RESULT is the visual center.
   ============================================================================ */
.lens-panel {
  position: fixed; z-index: 2147483647;
  width: min(380px, calc(100vw - 24px)); max-height: min(460px, calc(100vh - 24px));
  overflow: hidden;
  border: 1px solid var(--lens-line); border-radius: var(--lens-r-lg);
  background: var(--lens-srf); color: var(--lens-fg);
  box-shadow: var(--lens-shadow);
  font: 13px/1.55 var(--lens-font);
  opacity: 0; transform: translateY(2px);
  transition: opacity .16s var(--lens-ease), transform .16s var(--lens-ease);
}
.lens-panel[data-visible="true"] { opacity: 1; transform: none; }
.lens-panel-header {
  display: flex; align-items: center; justify-content: space-between; gap: 12px;
  padding: 12px 12px 12px 16px; border-bottom: 1px solid var(--lens-line);
}
.lens-panel-title {
  font-size: 11px; font-weight: 600; color: var(--lens-muted);
  text-transform: uppercase; letter-spacing: 0.07em;
}
.lens-panel-actions { display: inline-flex; gap: 4px; }
/* Text-only ghost icon actions; reveal a subtle srf-2 hover surface */
.lens-icon-btn {
  display: inline-flex; align-items: center;
  min-height: 28px; padding: 0 10px;
  border: 1px solid transparent; border-radius: var(--lens-r-sm);
  color: var(--lens-muted); background: transparent; cursor: pointer;
  font: 500 12px/1 var(--lens-font); letter-spacing: -0.003em;
  transition: color .14s var(--lens-ease), background-color .14s var(--lens-ease),
              border-color .14s var(--lens-ease);
}
.lens-icon-btn:hover { color: var(--lens-fg); background: var(--lens-srf-2); }
.lens-icon-btn:active { background: var(--lens-srf-2); }
.lens-icon-btn:focus-visible { outline: 2px solid var(--lens-accent); outline-offset: 1px; }
.lens-icon-btn:disabled { opacity: 0.5; cursor: not-allowed; }
.lens-panel-body { display: grid; gap: 12px; max-height: 352px; overflow: auto; padding: 16px; }
.lens-panel-source {
  max-height: 96px; overflow: auto; padding: 10px 12px;
  border: 1px solid var(--lens-line); border-radius: var(--lens-r-sm);
  color: var(--lens-muted); background: var(--lens-srf-2);
  font-size: 12px; line-height: 1.55;
}
/* Result is chrome (selection popover), so it tracks the surface-aware chrome
   accent \u2014 NOT the per-page runtime payload color (--lens-color), which is a
   light-mode preset and would fail contrast on the dark panel surface. */
.lens-panel-result {
  white-space: pre-wrap; color: var(--lens-accent);
  font-size: 15px; font-weight: 500; line-height: 1.65; min-height: 1.4em;
}
.lens-panel-result.is-loading { color: var(--lens-muted); font-weight: 450; font-style: italic; }
.lens-panel-result.is-error { color: var(--lens-error); font-weight: 500; }
.lens-panel-footer {
  padding: 0 16px 14px; color: var(--lens-muted);
  font-size: 11px; font-weight: 500; text-align: right;
  letter-spacing: 0.02em; font-variant-numeric: tabular-nums;
}

/* ============================================================================
   Toast \u2014 ink card; tone read from a slim 2px left bar (::before), never a fill.
   ============================================================================ */
.lens-toast {
  position: fixed; z-index: 2147483647; right: 18px; bottom: 18px;
  max-width: min(380px, calc(100vw - 36px));
  padding: 11px 14px 11px 16px;
  border: 1px solid var(--lens-line); border-radius: var(--lens-r-sm);
  background: var(--lens-srf); color: var(--lens-fg);
  box-shadow: var(--lens-shadow);
  font: 13px/1.5 var(--lens-font); letter-spacing: -0.002em;
  font-variant-numeric: tabular-nums;
}
.lens-toast::before {
  content: ""; position: absolute; left: 0; top: 8px; bottom: 8px;
  width: 2px; border-radius: 2px; background: var(--lens-muted);
}
.lens-toast[data-tone="success"]::before { background: var(--lens-accent); }
.lens-toast[data-tone="warning"]::before { background: var(--lens-warning); }
.lens-toast[data-tone="error"]::before   { background: var(--lens-error); }

/* ============================================================================
   Floating action button (FAB) \u2014 neutral premium INK anchor over any page.
   The wrap is exactly FAB-sized and pinned by its corner; the action menu is
   absolutely positioned so revealing it never nudges the FAB, and it flips
   up/down + left/right (data-flip / data-side) to stay on-screen when dragged.
   The wrap stays pointer-events:none so only the buttons intercept page clicks.
   Accent appears only on the auto-translate ON state and focus rings.
   ============================================================================ */
.lens-bubble-wrap {
  position: fixed; z-index: 2147483646; right: 18px; bottom: 78px;
  width: var(--lens-fab); height: var(--lens-fab);
  pointer-events: none;
}
.lens-bubble {
  position: relative; pointer-events: auto;
  width: var(--lens-fab); height: var(--lens-fab); padding: 0;
  border: none; border-radius: var(--lens-r-lg);
  display: grid; place-items: center;
  color: #FAFAF9; background: #18181B;
  box-shadow: var(--lens-shadow);
  cursor: pointer; user-select: none; touch-action: none;
  font: 600 15px/1 var(--lens-font);
  transition: background-color .14s var(--lens-ease), transform .14s var(--lens-ease),
              box-shadow .14s var(--lens-ease);
}
.lens-bubble:hover { background: #27272A; transform: translateY(-1px); }
.lens-bubble:active { transform: translateY(0); }
.lens-bubble:focus-visible { outline: 2px solid var(--lens-accent); outline-offset: 3px; }
.lens-bubble[data-busy="true"] { background: var(--lens-fg-2); cursor: progress; }
.lens-bubble[data-busy="true"]:hover { transform: none; }
.lens-bubble[data-busy="true"] span { opacity: 0; }
.lens-bubble[data-busy="true"]::after {
  content: ""; position: absolute; inset: 0; margin: auto; width: 18px; height: 18px;
  border: 2px solid rgba(250,250,249,0.30); border-top-color: #FAFAF9; border-radius: 50%;
  animation: lens-spin .8s linear infinite;
}
/* Live progress reads off the FAB itself \u2014 a hairline fill along its bottom edge \u2014
   so a long page no longer needs a stream of progress toasts to show it is alive. */
.lens-bubble::before {
  content: ""; position: absolute; left: 0; bottom: 0; height: 2px;
  width: var(--lens-progress, 0%);
  border-end-start-radius: var(--lens-r-lg);
  background: var(--lens-accent);
  opacity: 0; transition: width .2s var(--lens-ease), opacity .2s var(--lens-ease);
}
.lens-bubble[data-busy="true"]::before { opacity: 1; }

/* Revealed labeled action chips \u2014 absolutely anchored to the FAB so opening
   never moves it. Default: above the FAB, right-aligned. */
.lens-actions {
  position: absolute; right: 0; bottom: calc(100% + 8px);
  display: flex; flex-direction: column; align-items: flex-end; gap: 8px;
  opacity: 0; transform: translateY(4px); pointer-events: none;
  transition: opacity .16s var(--lens-ease), transform .18s var(--lens-ease);
}
/* Flip below when dropped near the top edge. */
.lens-bubble-wrap[data-flip="down"] .lens-actions {
  bottom: auto; top: calc(100% + 8px); transform: translateY(-4px);
}
/* Anchor + align to the left when dropped on the left half. */
.lens-bubble-wrap[data-side="left"] .lens-actions {
  right: auto; left: 0; align-items: flex-start;
}
.lens-bubble-wrap[data-open="true"] .lens-actions,
.lens-bubble-wrap:focus-within .lens-actions {
  opacity: 1; transform: none; pointer-events: auto;
}
/* While dragging, hide the menu and freeze FAB micro-motion. */
.lens-bubble-wrap[data-dragging="true"] .lens-actions { display: none; }
.lens-bubble-wrap[data-dragging="true"] .lens-bubble {
  transition: none; transform: none; cursor: grabbing;
}
.lens-mini {
  /* No explicit pointer-events: chips inherit it from .lens-actions, which is
     'none' while the menu is closed \u2014 so the invisible (opacity:0) chips never
     intercept clicks/hover in the band above the FAB, only when actually open. */
  display: inline-flex; align-items: center; gap: 8px;
  height: 32px; padding: 0 14px 0 10px;
  border: 1px solid var(--lens-line); border-radius: var(--lens-r-sm);
  background: var(--lens-srf); color: var(--lens-fg-2);
  box-shadow: var(--lens-shadow); cursor: pointer; white-space: nowrap;
  font: 500 12px/1 var(--lens-font); letter-spacing: -0.003em;
  transition: background-color .12s var(--lens-ease), color .12s var(--lens-ease),
              border-color .12s var(--lens-ease), transform .12s var(--lens-ease);
}
.lens-mini:hover { background: var(--lens-srf-2); border-color: var(--lens-line-2); color: var(--lens-fg); transform: translateY(-1px); }
.lens-mini:active { transform: translateY(0); }
.lens-mini:focus-visible { outline: 2px solid var(--lens-accent); outline-offset: 2px; }
.lens-mini-icon {
  display: inline-grid; place-items: center; width: 18px; height: 18px; border-radius: 6px;
  background: var(--lens-srf-2); border: 1px solid var(--lens-line);
  color: var(--lens-fg-2); font-size: 11px; font-weight: 600;
  transition: background-color .12s var(--lens-ease), color .12s var(--lens-ease),
              border-color .12s var(--lens-ease);
}
.lens-mini:hover .lens-mini-icon { border-color: var(--lens-line-2); }

/* Auto-translate ON = the one place the accent lives on the page chrome */
.lens-auto[data-enabled="true"] {
  background: var(--lens-accent); color: var(--lens-on-accent); border-color: transparent;
}
.lens-auto[data-enabled="true"]:hover {
  background: var(--lens-accent-hover); color: var(--lens-on-accent);
}
.lens-auto[data-enabled="true"] .lens-mini-icon {
  background: rgba(255,255,255,0.20); border-color: transparent; color: var(--lens-on-accent);
}
.lens-auto[data-enabled="true"]:hover .lens-mini-icon { border-color: transparent; }

/* Close \u2014 quiet danger intent on hover only (never a recolored resting border) */
.lens-close:hover {
  background: var(--lens-srf);
  border-color: color-mix(in srgb, var(--lens-error) 40%, var(--lens-line));
  color: var(--lens-error);
}
.lens-close:hover .lens-mini-icon {
  border-color: color-mix(in srgb, var(--lens-error) 40%, var(--lens-line));
  color: var(--lens-error);
}

@keyframes lens-spin { to { transform: rotate(360deg); } }

/* ============================================================================
   Dark mode \u2014 accent-fill split + FAB stays the high-contrast paper anchor.
   ============================================================================ */
@media (prefers-color-scheme: dark) {
  /* Selection mark uses an accent FILL: keep #0F766E + white text. */
  .lens-selection-bubble-mark { background: #0F766E; color: #FFFFFF; }

  /* FAB flips to paper fill with ink "\u8BD1" so it stays the highest-contrast anchor. */
  .lens-bubble { background: #FAFAF9; color: #18181B; }
  .lens-bubble:hover { background: #FFFFFF; }
  .lens-bubble[data-busy="true"] { background: var(--lens-fg-2); color: #18181B; }
  .lens-bubble[data-busy="true"]::after {
    border-color: rgba(24,24,27,0.30); border-top-color: #18181B;
  }

  /* Auto ON fill uses #0F766E + white text for legibility in dark. */
  .lens-auto[data-enabled="true"] { background: #0F766E; color: #FFFFFF; }
  .lens-auto[data-enabled="true"]:hover { background: #0B5E57; color: #FFFFFF; }
  .lens-auto[data-enabled="true"] .lens-mini-icon { background: rgba(255,255,255,0.20); color: #FFFFFF; }

  .lens-close:hover { color: var(--lens-error); border-color: color-mix(in srgb, var(--lens-error) 45%, var(--lens-line)); }
  .lens-close:hover .lens-mini-icon { color: var(--lens-error); border-color: color-mix(in srgb, var(--lens-error) 45%, var(--lens-line)); }
}

/* ============================================================================
   Reduced motion
   ============================================================================ */
@media (prefers-reduced-motion: reduce) {
  .lens-selection-bubble, .lens-panel, .lens-icon-btn, .lens-mini,
  .lens-mini-icon, .lens-bubble, .lens-actions, .lens-toast {
    transition: opacity .12s linear !important;
    transform: none !important;
  }
  .lens-bubble:hover, .lens-mini:hover,
  .lens-auto[data-enabled="true"]:hover { transform: none !important; }
  .lens-bubble[data-busy="true"]::after { animation: none; }
  .lens-pending::after { animation: none; }
}

/* ============================================================================
   Narrow viewport
   ============================================================================ */
@media (max-width: 520px) {
  .lens-bubble-wrap { right: 12px; bottom: 70px; }
}
`;var ue="lensBubblePos",Bt=5,R=8,_t=130,W=class{constructor(e){this.handlers=e}handlers;wrap=null;main=null;autoBtn=null;modeBtn=null;autoEnabled=!1;displayMode="bilingual";busy=!1;closeTimer=null;pos=null;dragging=!1;suppressClick=!1;pointerStart=null;originStart=null;mount(){if(this.wrap||!document.documentElement)return;y();let e=document.createElement("div");e.className="lens-bubble-wrap",e.dataset.lensUi="bubble",e.dataset.open="false";let t=document.createElement("div");t.className="lens-actions";let r=ce("lens-auto","A",a("bubbleAuto"),a("autoTranslate")),o=ce("lens-mode","\u53CC",a("bubbleMode"),a("labelDisplayMode")),i=ce("lens-close","\u2715",a("bubbleClose"),a("disableBubble"));t.append(r,o,i);let s=document.createElement("button");s.type="button",s.className="lens-bubble",s.dataset.busy="false",s.setAttribute("aria-label",a("translatePage")),s.title=a("translatePage");let l=document.createElement("span");l.textContent=a("badge"),s.appendChild(l),b(s,()=>{if(this.suppressClick){this.suppressClick=!1;return}this.handlers.onTranslate()}),b(r,()=>this.handlers.onToggleAuto()),b(o,()=>this.handlers.onToggleDisplayMode()),b(i,()=>this.handlers.onDisable()),this.attachDrag(s);let h=()=>{this.dragging||(this.closeTimer!==null&&(clearTimeout(this.closeTimer),this.closeTimer=null),this.updateMenuPlacement(),e.dataset.open="true")},d=()=>{this.closeTimer!==null&&clearTimeout(this.closeTimer),this.closeTimer=window.setTimeout(()=>{this.closeTimer=null,this.wrap&&(this.wrap.dataset.open="false")},160)};for(let S of[s,t])S.addEventListener("mouseenter",h),S.addEventListener("mouseleave",d);e.append(t,s),document.documentElement.appendChild(e),this.wrap=e,this.main=s,this.autoBtn=r,this.modeBtn=o,window.addEventListener("resize",this.onResize),this.updateMenuPlacement(),this.restorePosition(),this.refresh()}unmount(){this.closeTimer!==null&&(clearTimeout(this.closeTimer),this.closeTimer=null),window.removeEventListener("resize",this.onResize),this.wrap?.remove(),this.wrap=null,this.main=null,this.autoBtn=null,this.modeBtn=null,this.dragging=!1}get mounted(){return!!this.wrap}setBusy(e){this.busy=e,this.main&&(this.main.dataset.busy=e?"true":"false",this.main.setAttribute("aria-busy",e?"true":"false"),e||(this.main.style.removeProperty("--lens-progress"),this.main.title=a("translatePage")))}setProgress(e,t){if(!this.main)return;let r=t>0?Math.max(2,Math.min(100,Math.round(e/t*100))):0;this.main.style.setProperty("--lens-progress",`${r}%`),this.main.title=t>0&&e<t?`${a("translating")} ${e}/${t}`:a("translatePage")}setAutoEnabled(e){this.autoEnabled=e,this.refresh()}setDisplayMode(e){this.displayMode=e,this.refresh()}attachDrag(e){e.addEventListener("pointerdown",r=>{if(!r.isTrusted||r.button!==0||!this.wrap)return;this.suppressClick=!1,this.pointerStart={x:r.clientX,y:r.clientY};let o=this.wrap.getBoundingClientRect();this.originStart={x:o.left,y:o.top};try{e.setPointerCapture(r.pointerId)}catch{}}),e.addEventListener("pointermove",r=>{if(!r.isTrusted||!this.pointerStart||!this.originStart)return;let o=r.clientX-this.pointerStart.x,i=r.clientY-this.pointerStart.y;!this.dragging&&Math.hypot(o,i)<Bt||(r.preventDefault(),this.dragging||this.beginDrag(),this.setPosition(this.originStart.x+o,this.originStart.y+i))});let t=r=>{if(!(!r.isTrusted||!this.pointerStart)){try{e.releasePointerCapture(r.pointerId)}catch{}this.pointerStart=null,this.originStart=null,this.dragging&&(this.endDrag(),this.suppressClick=!0,setTimeout(()=>this.suppressClick=!1,0),this.persistPosition())}};e.addEventListener("pointerup",t),e.addEventListener("pointercancel",t)}beginDrag(){this.dragging=!0,this.wrap&&(this.wrap.dataset.dragging="true",this.wrap.dataset.open="false"),this.closeTimer!==null&&(clearTimeout(this.closeTimer),this.closeTimer=null)}endDrag(){this.dragging=!1,this.wrap&&delete this.wrap.dataset.dragging,this.main?.blur()}setPosition(e,t){if(!this.wrap)return;let r=this.wrap.offsetWidth||38,o=Math.max(R,window.innerWidth-r-R),i=Math.max(R,window.innerHeight-r-R),s=Ue(e,R,o),l=Ue(t,R,i);this.wrap.style.left=`${s}px`,this.wrap.style.top=`${l}px`,this.wrap.style.right="auto",this.wrap.style.bottom="auto",this.pos={x:s,y:l},this.updateMenuPlacement()}updateMenuPlacement(){if(!this.wrap)return;let e=this.wrap.getBoundingClientRect();this.wrap.dataset.flip=e.top<_t?"down":"up",this.wrap.dataset.side=e.left+e.width/2>window.innerWidth/2?"right":"left"}restorePosition(){try{chrome.storage.local.get(ue).then(e=>{let t=e?.[ue];t&&Number.isFinite(t.x)&&Number.isFinite(t.y)&&this.wrap&&this.setPosition(t.x,t.y)})}catch{}}persistPosition(){if(this.pos)try{chrome.storage.local.set({[ue]:this.pos})}catch{}}onResize=()=>{this.pos?this.setPosition(this.pos.x,this.pos.y):this.updateMenuPlacement()};refresh(){if(this.autoBtn&&(this.autoBtn.dataset.enabled=this.autoEnabled?"true":"false",this.autoBtn.setAttribute("aria-pressed",this.autoEnabled?"true":"false"),this.autoBtn.title=this.autoEnabled?a("autoOff"):a("autoOn"),_e(this.autoBtn,a("bubbleAuto"),this.autoEnabled?a("stateOn"):a("stateOff"))),this.modeBtn){let e=this.displayMode==="bilingual";this.modeBtn.dataset.mode=this.displayMode;let t=e?a("displayBilingual"):a("displayReplace");this.modeBtn.title=t,this.modeBtn.setAttribute("aria-label",t),Ut(this.modeBtn,e?"\u53CC":"\u5355"),_e(this.modeBtn,a("bubbleMode"),e?a("modeShortBilingual"):a("modeShortReplace"))}this.main&&(this.main.dataset.busy=this.busy?"true":"false")}};function ce(n,e,t,r){let o=document.createElement("button");o.type="button",o.className=`lens-mini ${n}`,o.title=r,o.setAttribute("aria-label",r);let i=document.createElement("span");i.className="lens-mini-icon",i.textContent=e;let s=document.createElement("span");return s.className="lens-mini-label",s.textContent=t,o.append(i,s),o}function Ut(n,e){let t=n.querySelector(".lens-mini-icon");t&&(t.textContent=e)}function _e(n,e,t){let r=n.querySelector(".lens-mini-label");r&&(r.textContent=`${e} \xB7 ${t}`)}function Ue(n,e,t){return Math.min(t,Math.max(e,n))}var He="lens-session",V="lens-selection";var f=null,C=null;function u(n,e="info",t=3500){y(),f||(f=document.createElement("div"),f.className="lens-toast",f.dataset.lensUi="toast",f.setAttribute("role","status"),document.documentElement.appendChild(f)),f.textContent=n,f.dataset.tone=e,C&&clearTimeout(C),C=setTimeout(G,t)}function G(){C&&(clearTimeout(C),C=null),f?.remove(),f=null}function $e(){let n=Ht(document.activeElement);if(!n){u(a("toastNoText"),"info",2200);return}let e=ze(n),t=e.trim();if(!t){u(a("toastNoText"),"info",2200);return}u(a("translating"),"info",4e3);let r="";try{x();let o=chrome.runtime.connect({name:V});o.onMessage.addListener(i=>{if(i.type==="DELTA")r+=i.chunk;else if(i.type==="DONE"){let s=i.translated||r;!n.isConnected||ze(n)!==e?u(a("toastInputChanged"),"info",3e3):s&&(zt(n,s),u(a("panelTranslated"),"success",1800));try{o.disconnect()}catch{}}else if(i.type==="ERROR"){u(i.message,"error",4e3);try{o.disconnect()}catch{}}}),o.postMessage({type:"TRANSLATE",text:t})}catch(o){u(g(o),"error",4e3)}}function Ht(n){return n&&(n instanceof HTMLTextAreaElement||n instanceof HTMLInputElement&&/^(text|search|url|email|)$/i.test(n.type)||n instanceof HTMLElement&&n.isContentEditable)?n:null}function ze(n){return n instanceof HTMLTextAreaElement||n instanceof HTMLInputElement?n.value:n.textContent??""}function zt(n,e){if(n instanceof HTMLTextAreaElement||n instanceof HTMLInputElement){let t=n instanceof HTMLTextAreaElement?HTMLTextAreaElement.prototype:HTMLInputElement.prototype,r=Object.getOwnPropertyDescriptor(t,"value")?.set;r?r.call(n,e):n.value=e,n.dispatchEvent(new Event("input",{bubbles:!0})),n.dispatchEvent(new Event("change",{bubbles:!0}))}else n.textContent=e,n.dispatchEvent(new Event("input",{bubbles:!0}))}function We(n,e){return p(n).toLowerCase()===p(e).toLowerCase()}var K=class{records=new Map;displayMode="bilingual";langTag=null;appliedCount=0;setDisplayMode(e){if(e!==this.displayMode){this.displayMode=e;for(let t of this.records.values()){if(t.mode==="attribute"||t.mode==="swap"||!t.translated)continue;let r=t.tr;r&&(e==="replace"?this.hideSource(t):this.showSource(t),r.className=this.trClass(t.mode),t.failed&&r.classList.add("lens-error"))}}}setTargetLang(e){this.langTag=U(e)}get size(){return this.records.size}has(e){return this.records.has(e)}register(e,t){let r={id:e,unit:t,mode:t.renderMode,tr:null,applied:!1,attrHandled:!1,titleAdded:!1,originalTitle:null,ariaAdded:!1,originalAria:null,originalValues:null,titleEl:null,translated:null,failed:!1};if(t.renderMode==="attribute")t.block.dataset.lens="attr";else if(t.renderMode==="swap")t.block.dataset.lens="swap";else{t.block.dataset.lens="1";let o=this.createTr(t.renderMode);o.classList.add("lens-pending"),o.setAttribute("aria-busy","true"),o.setAttribute("aria-label",a("labelPending")),this.insert(t,o),r.tr=o}this.records.set(e,r)}applyTranslation(e,t){let r=this.records.get(e);if(!r||!t)return;if(r.translated=t,r.failed=!1,r.mode==="attribute"){this.applyAttribute(r,t),this.markApplied(r);return}if(r.mode==="swap"){We(t,r.unit.text)||this.swapText(r,t),this.markApplied(r);return}if(We(t,r.unit.text)){r.tr?.remove(),r.tr=null,this.markApplied(r);return}let o=this.ensureTr(r);if(!o){this.markApplied(r);return}o.textContent=t,o.className=this.trClass(r.mode),o.removeAttribute("aria-busy"),o.removeAttribute("aria-label"),o.removeAttribute("title"),this.displayMode==="replace"&&this.hideSource(r),this.markApplied(r)}markError(e,t){let r=this.records.get(e);if(!r)return;if(r.failed=!0,r.mode==="attribute"){this.captureAttr(r),r.unit.block.title=`${p(r.unit.text)}
${t}`,this.markApplied(r);return}let o=r.tr;if(!o){this.markApplied(r);return}o.textContent=a("labelError"),o.className=`${this.trClass(r.mode)} lens-error`,o.title=t,o.removeAttribute("aria-busy"),this.markApplied(r)}unresolvedSegments(){let e=[];for(let t of this.records.values())!t.applied&&t.unit.block.isConnected&&e.push({id:t.id,text:t.unit.text});return e}dropUnresolved(){for(let e of[...this.records.values()])e.applied||(e.tr?.remove(),delete e.unit.block.dataset.lens,delete e.unit.block.dataset.lensId,this.records.delete(e.id))}restoreAll(){for(let e of this.records.values()){if(e.mode==="attribute"){this.restoreAttribute(e);continue}e.tr?.remove(),this.showSource(e),e.mode==="swap"&&this.restoreTitle(e),delete e.unit.block.dataset.lens,delete e.unit.block.dataset.lensId}this.records.clear(),this.appliedCount=0}trClass(e){return e==="swap"||this.displayMode==="replace"?"lens-replace":e==="inline"?"lens-inline":"lens-block"}swapText(e,t){let r=e.unit.nodes,o=r.findIndex(s=>s.isConnected);if(o<0)return;e.originalValues||(e.originalValues=r.map(s=>s.nodeValue??"")),r.forEach((s,l)=>{s.isConnected&&(s.nodeValue=l===o?t:"")});let i=r[o].parentElement??e.unit.block;i.getAttribute("title")==null&&(i.setAttribute("title",p(e.unit.text)),e.titleEl=i)}restoreTitle(e){e.titleEl?.removeAttribute("title"),e.titleEl=null}createTr(e){let t=document.createElement("span");return t.className=this.trClass(e),t.dataset.lensUi="tr",t.setAttribute("translate","no"),t.setAttribute("dir","auto"),this.langTag&&t.setAttribute("lang",this.langTag),t}insert(e,t){let r=e.block,o=e.nodes[e.nodes.length-1],i=null;if(o&&o.isConnected){let s=o;for(;s.parentNode&&s.parentNode!==r;)s=s.parentNode;s.parentNode===r&&(i=s)}i&&i.nextSibling?r.insertBefore(t,i.nextSibling):r.appendChild(t)}ensureTr(e){if(e.tr&&e.tr.isConnected)return e.tr;if(!e.unit.block.isConnected)return null;let t=this.createTr(e.mode);return this.insert(e.unit,t),e.tr=t,t}hideSource(e){if(!e.originalValues){e.originalValues=e.unit.nodes.map(t=>t.nodeValue??"");for(let t of e.unit.nodes)t.isConnected&&(t.nodeValue="")}}showSource(e){let t=e.originalValues;t&&(e.unit.nodes.forEach((r,o)=>{r.isConnected&&(r.nodeValue=t[o])}),e.originalValues=null)}captureAttr(e){if(e.attrHandled)return;let t=e.unit.block;e.originalTitle=t.getAttribute("title"),e.titleAdded=e.originalTitle==null,e.originalAria=t.getAttribute("aria-label"),e.ariaAdded=e.originalAria==null,e.attrHandled=!0}applyAttribute(e,t){let r=e.unit.block,o=p(e.unit.text);this.captureAttr(e),r.dataset.lens="attr",r.title=`${o}
${a("badge")}: ${t}`,e.ariaAdded&&r.setAttribute("aria-label",`${o}, ${t}`)}restoreAttribute(e){let t=e.unit.block;delete t.dataset.lens,delete t.dataset.lensId,e.titleAdded?t.removeAttribute("title"):e.originalTitle!=null&&t.setAttribute("title",e.originalTitle),e.ariaAdded?t.removeAttribute("aria-label"):e.originalAria!=null&&t.setAttribute("aria-label",e.originalAria)}markApplied(e){e.applied||(e.applied=!0,this.appliedCount+=1)}};var Y=class{panel=null;resultEl=null;footerEl=null;port=null;requestId=0;selectionText="";anchorRect=null;streamed="";langTag=null;onKeyDown=e=>this.onKeyDown_(e);init(){document.addEventListener("keydown",this.onKeyDown,!0)}setTargetLang(e){this.langTag=U(e)}destroy(){document.removeEventListener("keydown",this.onKeyDown,!0),this.disconnectPort(),this.closePanel()}translateSelection(e,t){e&&(this.selectionText=e,this.anchorRect=t,this.openAndTranslate())}translateCurrentSelection(){let e=I();return e?(this.translateSelection(e.text,e.rect),!0):!1}onKeyDown_(e){e.key!=="Escape"||!this.panel||this.closePanel()}openAndTranslate(){let e=this.selectionText,t=this.anchorRect;if(!e||!t)return;this.renderPanel(t,e,"loading");let r=++this.requestId;this.streamed="";try{x(),this.disconnectPort();let o=chrome.runtime.connect({name:V});this.port=o,o.onMessage.addListener(i=>this.onPortMessage(i,r)),o.onDisconnect.addListener(()=>{this.port===o&&(this.port=null)}),o.postMessage({type:"TRANSLATE",text:e})}catch(o){this.setResult(g(o),"error")}}onPortMessage(e,t){t===this.requestId&&(e.type==="DELTA"?(this.streamed+=e.chunk,this.setResult(this.streamed,"result")):e.type==="DONE"?(this.setResult(e.translated,"result"),this.footerEl&&(this.footerEl.textContent=e.fromCache?a("panelFromCache"):a("panelTranslated")),this.disconnectPort()):e.type==="ERROR"&&(this.setResult(e.message,"error"),this.disconnectPort()))}renderPanel(e,t,r){this.closePanel(),y();let o=document.createElement("section");o.className="lens-panel",o.dataset.lensUi="panel",o.setAttribute("role","dialog"),o.setAttribute("aria-label",a("panelTitle")),o.addEventListener("mousedown",Ve=>Ve.stopPropagation());let i=document.createElement("div");i.className="lens-panel-header";let s=document.createElement("div");s.className="lens-panel-title",s.textContent=a("panelTitle");let l=document.createElement("div");l.className="lens-panel-actions";let h=de(a("panelSpeak"),()=>this.speak()),d=de(a("panelCopy"),()=>this.copyResult(d)),S=de(a("panelClose"),()=>this.closePanel());l.append(h,d,S),i.append(s,l);let M=document.createElement("div");M.className="lens-panel-body";let v=document.createElement("div");v.className="lens-panel-source",v.textContent=t;let O=document.createElement("div");O.className="lens-panel-result is-loading",O.textContent=a("panelTranslating"),M.append(v,O);let D=document.createElement("div");D.className="lens-panel-footer",D.textContent=r==="loading"?a("appName"):a("panelTranslated"),o.append(i,M,D),document.documentElement.appendChild(o),this.panel=o,this.resultEl=O,this.footerEl=D,requestAnimationFrame(()=>{F(o,e,{gap:10,preferred:"below"}),o.dataset.visible="true"})}setResult(e,t){this.resultEl&&(this.resultEl.classList.remove("is-loading","is-error"),t==="error"&&this.resultEl.classList.add("is-error"),this.resultEl.textContent=e)}copyResult(e){let t=this.resultEl?.textContent??"";t&&$t(t).then(r=>{e.textContent=r?"\u2713":a("panelCopy"),setTimeout(()=>e.textContent=a("panelCopy"),1400)})}speak(){let e=this.resultEl?.textContent??"";if(!e||!("speechSynthesis"in window))return;window.speechSynthesis.cancel();let t=new SpeechSynthesisUtterance(e);this.langTag&&(t.lang=this.langTag),window.speechSynthesis.speak(t)}closePanel(){try{window.speechSynthesis?.cancel()}catch{}this.panel?.remove(),this.panel=null,this.resultEl=null,this.footerEl=null}disconnectPort(){if(this.port){try{this.port.disconnect()}catch{}this.port=null}}};function de(n,e){let t=document.createElement("button");return t.type="button",t.className="lens-icon-btn",t.textContent=n,t.title=n,b(t,e),t}async function $t(n){try{if(navigator.clipboard?.writeText)return await navigator.clipboard.writeText(n),!0}catch{}try{let e=document.createElement("textarea");e.value=n,e.style.position="fixed",e.style.left="-9999px",e.dataset.lensUi="clip",document.documentElement.appendChild(e),e.select();let t=document.execCommand("copy");return e.remove(),t}catch{return!1}}var q=class{constructor(e,t,r){this.renderer=e;this.segments=t;this.handlers=r}renderer;segments;handlers;port=null;writes=new Map;errors=new Map;flushScheduled=!1;finished=!1;start(){x(),this.port=chrome.runtime.connect({name:He}),this.port.onMessage.addListener(e=>this.onMessage(e)),this.port.onDisconnect.addListener(()=>this.onDisconnect()),this.handlers.onBusy(!0),this.port.postMessage({type:"START_TRANSLATION",segments:this.segments})}append(e){if(!this.port||this.finished||!e.length)return!1;try{return this.port.postMessage({type:"APPEND_SEGMENTS",segments:e}),!0}catch{return!1}}cancel(){if(this.finished=!0,this.port)try{this.port.postMessage({type:"CANCEL_TRANSLATION"})}catch{}this.teardown()}get active(){return!!this.port&&!this.finished}onMessage(e){switch(e.type){case"SESSION_STARTED":this.handlers.onSettings(e.settings);break;case"TRANSLATION_RESULT":for(let t of e.items)this.queueWrite(t.id,t.translated);break;case"TRANSLATION_ERROR":for(let t of e.ids)this.queueError(t,e.message);break;case"PROGRESS":this.handlers.onProgress(e);break;case"RETRYING":this.handlers.onRetry(e.message);break;case"SESSION_COMPLETE":this.flush(),this.finished=!0,this.teardown(),this.handlers.onComplete(e);break;case"SESSION_CANCELLED":this.finished=!0,this.teardown(),this.handlers.onCancelled();break;case"FATAL_ERROR":this.finished=!0,this.teardown(),this.handlers.onFatal(e.message);break}}onDisconnect(){this.port=null,this.finished||(this.finished=!0,this.flush(),this.handlers.onBusy(!1),this.handlers.onDropped())}teardown(){if(this.port){try{this.port.disconnect()}catch{}this.port=null}this.handlers.onBusy(!1)}queueWrite(e,t){t&&(this.writes.set(e,t),this.scheduleFlush())}queueError(e,t){this.errors.set(e,t),this.scheduleFlush()}scheduleFlush(){this.flushScheduled||(this.flushScheduled=!0,requestAnimationFrame(()=>this.flush()))}flush(){if(this.flushScheduled=!1,this.writes.size){let e=this.writes;this.writes=new Map;for(let[t,r]of e)this.renderer.applyTranslation(t,r)}if(this.errors.size){let e=this.errors;this.errors=new Map;for(let[t,r]of e)this.renderer.markError(t,r)}}};var Wt=900,Vt=400,Gt=40;function pe(){return document.visibilityState==="visible"}var j=class{io=null;mo=null;observed=new WeakSet;enabled=!1;passTimer=null;rescanTimer=null;options;ready=new Set;addedRoots=new Set;fullRescan=!1;firstPassDone=!1;passDeadline=0;constructor(e){this.options=e}update(e){this.options={...this.options,...e}}enable(){if(this.enabled)return;this.enabled=!0;let e=Math.max(120,Math.round(window.innerHeight*this.options.prefetchScreens));this.io=new IntersectionObserver(t=>this.onIntersect(t),{rootMargin:`${Math.min(300,Math.round(window.innerHeight*.4))}px 0px ${e}px 0px`}),this.observeAll(),this.mo=new MutationObserver(t=>this.onMutate(t)),this.mo.observe(document.body,{childList:!0,subtree:!0}),this.schedulePass(Math.min(650,this.options.debounceMs+200))}disable(){this.enabled=!1,this.io?.disconnect(),this.mo?.disconnect(),this.io=null,this.mo=null,this.observed=new WeakSet,this.ready.clear(),this.addedRoots.clear(),this.fullRescan=!1,this.passTimer&&clearTimeout(this.passTimer),this.rescanTimer&&clearTimeout(this.rescanTimer),this.passTimer=null,this.rescanTimer=null,this.passDeadline=0}reset(){this.observed=new WeakSet,this.ready.clear(),this.firstPassDone=!1,this.enabled&&(this.observeAll(),this.schedulePass(this.options.debounceMs))}nudge(e=200){this.enabled&&this.schedulePass(e)}observeAll(){this.observeUnits($(document.body))}observeUnits(e){if(this.io)for(let t of e){let r=t.block;this.observed.has(r)||r.dataset.lens||(this.observed.add(r),this.io.observe(r))}}onIntersect(e){let t=!1;for(let r of e)r.isIntersecting&&(this.io?.unobserve(r.target),r.target instanceof HTMLElement&&(this.ready.add(r.target),t=!0));t&&this.schedulePass(this.options.debounceMs)}onMutate(e){let t=!1;for(let r of e)for(let o of r.addedNodes){if(o.nodeType!==Node.ELEMENT_NODE)continue;let i=o;Yt(i)||(t=!0,this.addedRoots.size>=Gt?this.fullRescan=!0:this.addedRoots.add(i))}t&&this.scheduleRescan()}scheduleRescan(){this.rescanTimer||(this.rescanTimer=setTimeout(()=>{this.rescanTimer=null,this.enabled&&(this.observeAdded(),this.schedulePass(this.options.debounceMs))},Vt))}observeAdded(){if(this.fullRescan){this.fullRescan=!1,this.addedRoots.clear(),this.observeAll();return}if(!this.addedRoots.size)return;let e=[...this.addedRoots].filter(t=>t.isConnected);this.addedRoots.clear(),e.length&&this.observeUnits(se(e))}schedulePass(e){let t=Date.now();this.passDeadline||(this.passDeadline=t+Wt);let r=Math.max(0,Math.min(e,this.passDeadline-t));this.passTimer&&clearTimeout(this.passTimer),this.passTimer=setTimeout(()=>{this.passTimer=null,this.passDeadline=0,this.runPass()},r)}runPass(){if(!this.enabled||!pe())return;let e=Math.max(1,this.options.batchSize),t=this.unitsFromReady();if(!t.length&&!this.firstPassDone&&(t=N({limit:e,viewportOnly:!0,marginTop:Math.min(300,Math.round(window.innerHeight*.4)),marginBottom:Math.max(220,Math.round(window.innerHeight*this.options.prefetchScreens))})),this.firstPassDone=!0,!!t.length){if(t.length>e){for(let r of t.slice(e))this.ready.add(r.block);this.schedulePass(150),t=t.slice(0,e)}this.options.onPass(t)}}unitsFromReady(){if(!this.ready.size)return[];let e=[...this.ready].filter(r=>r.isConnected&&!r.dataset.lens);return this.ready.clear(),e.length?se(e).map(r=>({unit:r,top:Kt(r.block)})).sort((r,o)=>r.top-o.top).map(r=>r.unit):[]}};function Kt(n){try{let e=n.getBoundingClientRect();return(e.bottom>=0&&e.top<=window.innerHeight?0:1e5)+Math.abs(e.top)}catch{return Number.MAX_SAFE_INTEGER}}function Yt(n){return n instanceof HTMLElement&&!!(n.dataset.lens||n.dataset.lensUi)}var qt=2,jt=20,k=n=>n!=="auto",X=class{settings=null;renderer=new K;selection=new Y;bar=new B(({text:e,rect:t})=>this.selection.translateSelection(e,t));bubble=new W({onTranslate:()=>this.togglePage(),onToggleAuto:()=>{this.toggleAuto()},onToggleDisplayMode:()=>{this.toggleDisplayMode()},onDisable:()=>{this.setBubbleEnabled(!1)}});auto=new j({batchSize:80,prefetchScreens:1,debounceMs:400,onPass:e=>this.translateUnits(e,"auto")});session=null;sessionMode="manual";busy=!1;autoActive=!1;resubmits=0;sweepWaves=0;init(){return y(),ae("selection-bar",ye),this.selection.init(),this.bar.init(),chrome.storage.onChanged.addListener(this.onSettingsChanged),window.addEventListener("pagehide",this.onPageHide,!0),window.addEventListener("pageshow",this.onPageShow,!0),document.addEventListener("visibilitychange",this.onVisibilityChange),this.loadAndApply()}onSettingsChanged=(e,t)=>{t==="local"&&e[E]&&this.loadAndApply()};onPageHide=e=>{G(),this.session?.cancel(),!e.persisted&&(this.auto.disable(),this.autoActive=!1,this.bar.destroy(),this.selection.destroy(),this.bubble.unmount(),chrome.storage.onChanged.removeListener(this.onSettingsChanged),window.removeEventListener("pagehide",this.onPageHide,!0),window.removeEventListener("pageshow",this.onPageShow,!0),document.removeEventListener("visibilitychange",this.onVisibilityChange))};onPageShow=e=>{e.persisted&&this.loadAndApply()};onVisibilityChange=()=>{this.syncAuto()};loadAndApply(){return A().then(e=>this.applySettings(e)).catch(()=>{})}applySettings(e){this.settings=e,this.bar.setMode(Q(e,location.href)),le(e.translationColor),oe(e.translateUiText),this.renderer.setTargetLang(e.targetLang),this.selection.setTargetLang(e.targetLang),this.renderer.setDisplayMode(e.displayMode),this.bubble.setDisplayMode(e.displayMode),this.auto.update({batchSize:e.autoTranslateBatchSize,prefetchScreens:e.autoTranslatePrefetchScreens,debounceMs:e.autoTranslateDebounceMs}),he()&&e.floatingBubbleEnabled?this.bubble.mount():this.bubble.unmount(),this.bubble.setAutoEnabled(this.autoWanted()),this.syncAuto()}autoWanted(){return this.settings?te(this.settings,location.hostname):!1}syncAuto(){let e=this.autoWanted()&&pe();e&&!this.autoActive?(this.autoActive=!0,this.auto.enable()):!e&&this.autoActive&&(this.autoActive=!1,this.auto.disable())}async handleCommand(e){switch(e){case"SHOW_SELECTION_TOOLBAR":{let t=Q(await A(),location.href);if(this.bar.setMode(t),t==="off")throw new Error(this.text("selectionToolbarDisabled"));if(!this.bar.openManually())throw new Error(this.text("toastNoText"));return{}}case"TOGGLE_PAGE":return this.togglePage(),{};case"TRANSLATE_PAGE":return this.translatePage(),{};case"TRANSLATE_SELECTION":return this.selection.translateCurrentSelection()||u(this.text("toastNoText"),"info",2200),{};case"RESTORE_ORIGINAL":return this.restoreOriginal(),{};case"STOP_TRANSLATION":return this.stopSession(),u(this.text("toastStopped"),"info",2500),{};case"TOGGLE_AUTO":return this.toggleAuto(),{};case"TOGGLE_DISPLAY_MODE":return this.toggleDisplayMode(),{};case"TRANSLATE_INPUT":return $e(),{};case"GET_STATUS":return{active:this.renderer.size>0,translated:this.renderer.size,busy:this.busy,auto:this.autoWanted(),displayMode:this.settings?.displayMode??"bilingual"};default:return{}}}togglePage(){this.renderer.size>0?this.restoreOriginal():this.translatePage()}translatePage(){let e=this.settings;if(!e)return;this.renderer.size>0&&this.restoreOriginal({silent:!0}),this.sweepWaves=jt;let t=N({limit:e.maxSegments});this.translateUnits(t,"manual")}continueSweep(){if(this.sweepWaves<=0||!k(this.sessionMode)||!this.settings)return!1;this.sweepWaves-=1;let e=N({limit:this.settings.maxSegments});return e.length?this.translateUnits(e,"sweep"):(this.sweepWaves=0,!1)}translateUnits(e,t){if(!this.settings)return!1;let r=this.settings,o=[];for(let s of e)if(!this.renderer.has(s.block.dataset.lensId??"")){if(r.sourceSkip&&Me(s.text,r.targetLang)){s.block.dataset.lens="skip";continue}o.push(s)}if(!o.length)return t==="manual"&&u(this.text("toastNoText"),"info",2600),t==="sweep"&&(this.sweepWaves=0),!1;let i=o.map(s=>{let l=ve("seg");return s.block.dataset.lensId=l,this.renderer.register(l,s),{id:l,text:s.text}});return this.submit(i,t),!0}submit(e,t){try{x()}catch(r){this.sweepWaves=0,this.renderer.dropUnresolved(),u(g(r),"error",5e3);return}if(this.session?.active&&this.session.append(e)){k(t)&&!k(this.sessionMode)&&(this.sessionMode=t),t==="manual"&&u(this.text("toastSubmitted",[String(e.length)]),"info",2600);return}this.sessionMode=t,this.session=new q(this.renderer,e,{onBusy:r=>{this.busy=r,this.bubble.setBusy(r)},onProgress:r=>this.bubble.setProgress(r.completed+r.failed,r.total),onRetry:r=>{k(this.sessionMode)&&u(r,"warning",4e3)},onComplete:r=>{if(!this.resubmitUnresolved()&&!this.continueSweep()){if(k(this.sessionMode)){let o=r.failed?"warning":"success";u(this.text("toastComplete",[String(r.completed),String(r.total)]),o,3500)}else r.failed?u(this.text("toastComplete",[String(r.completed),String(r.total)]),"warning",3e3):G();this.autoActive&&this.auto.nudge()}},onCancelled:()=>{this.sweepWaves=0,this.renderer.dropUnresolved(),k(this.sessionMode)&&u(this.text("toastStopped"),"info",2500)},onDropped:()=>{this.resubmitUnresolved()||this.renderer.dropUnresolved()},onFatal:r=>{this.sweepWaves=0,this.renderer.dropUnresolved(),u(r,"error",6e3)},onSettings:r=>this.applyPublicSettings(r)}),t==="manual"&&u(this.text("toastSubmitted",[String(e.length)]),"info",3e3);try{this.session.start()}catch(r){this.busy=!1,this.bubble.setBusy(!1),this.renderer.dropUnresolved(),u(g(r),"error",5e3)}}resubmitUnresolved(){let e=this.renderer.unresolvedSegments();return e.length?this.resubmits>=qt?(this.resubmits=0,this.renderer.dropUnresolved(),!1):(this.resubmits+=1,this.session=null,this.submit(e,this.sessionMode),!0):(this.resubmits=0,!1)}applyPublicSettings(e){le(e.translationColor),oe(e.translateUiText),this.renderer.setTargetLang(e.targetLang),this.selection.setTargetLang(e.targetLang),this.renderer.setDisplayMode(e.displayMode),this.bubble.setDisplayMode(e.displayMode)}restoreOriginal(e={}){this.stopSession(),this.renderer.restoreAll(),document.querySelectorAll("[data-lens]").forEach(t=>{t.dataset.lensUi||(delete t.dataset.lens,delete t.dataset.lensId)}),this.auto.reset(),e.silent||u(this.text("toastRestored"),"success",2500)}stopSession(){this.session?.cancel(),this.session=null,this.resubmits=0,this.sweepWaves=0,this.busy=!1,this.bubble.setBusy(!1),this.renderer.dropUnresolved()}async toggleAuto(){let e=await A().catch(()=>this.settings);if(!e)return;let t=location.hostname,r=!te(e,t),o=T({...e,siteRules:Re(e,t,r)});await H(o).catch(()=>{}),this.applySettings(o),u(this.text(r?"autoOnHost":"autoOffHost",[t]),r?"success":"info",2600)}async toggleDisplayMode(){let e=await A().catch(()=>this.settings);if(!e)return;let t=e.displayMode==="bilingual"?"replace":"bilingual",r=T({...e,displayMode:t});await H(r).catch(()=>{}),this.applySettings(r),u(this.text(t==="bilingual"?"displayBilingual":"displayReplace"),"success",2e3)}async setBubbleEnabled(e){let t=await A().catch(()=>this.settings);t&&await H(T({...t,floatingBubbleEnabled:e})).catch(()=>{})}text(e,t){return chrome.i18n.getMessage(e,t)||e}};if(!window.__lensLoaded){window.__lensLoaded=!0;let n=new X,e=n.init();chrome.runtime.onMessage.addListener((t,r,o)=>t?.type!=="LENS_COMMAND"?!1:(e.then(()=>n.handleCommand(t.command)).then(i=>o({ok:!0,...i})).catch(i=>o({ok:!1,error:g(i)})),!0))}})();
